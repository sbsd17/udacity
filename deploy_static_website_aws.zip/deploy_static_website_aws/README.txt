CloudFront endpoint: https://d3fgct7j9rrb8w.cloudfront.net
Bucket website end-point: http://udacity-project-01-bucket.s3-website-us-east-1.amazonaws.com
S3 object url: http://udacity-project-01-bucket.s3.amazonaws.com/index.html